import json

class Player:
    def __init__(self, name):
        self.name = name
        self.current_room = None
        self.health = 100
        self.damage = 10

    def is_alive(self):
        return self.health > 0

class Room:
    def __init__(self, description):
        self.description = description
        self.doors = []
        self.npcs = []
        self.items = []

    def add_door(self, door):
        self.doors.append(door)

    def add_npc(self, npc):
        self.npcs.append(npc)

    def add_item(self, item):
        self.items.append(item)

class Door:
    def __init__(self, description):
        self.description = description
        self.room_behind = None

    def interact(self, player):
        print("You go through the door")
        player.current_room = self.room_behind

class NPC:
    def __init__(self, description):
        self.description = description
        self.health = 50
        self.damage = 5

    def is_alive(self):
        return self.health > 0

    def interact(self, player):
        print("You interact with the NPC")
        if self.health > 0:
            player.health -= self.damage
            print(f"You take {self.damage} damage from the NPC")
            if player.health <= 0:
                print("You die")
                return
            self.health -= player.damage
            print(f"You deal {player.damage} damage to the NPC")
            if self.health <= 0:
                print("The NPC dies")
        else:
            print("The NPC is already dead")

class Item:
    def __init__(self, description):
        self.description = description
        self.health_bonus = 10

    def interact(self, player):
        print("You pick up the item")
        player.health += self.health_bonus
        print(f"You gain {self.health_bonus} health")

class Game:
    def __init__(self):
        self.player = Player("Player")
        self.current_room = Room("You are in a room.")
        self.rooms = [self.current_room]
        self.doors = []
        self.npcs = []
        self.items = []

        # Create rooms and doors
        room1 = Room("A rather dusty room full of computers.")
        room2 = Room("A dark room with dark doors.")
        door1 = Door("A mysterious red door")
        door2 = Door("A black door")
        door1.room_behind = room2
        door2.room_behind = room1
        room1.add_door(door1)
        room1.add_door(door2)
        room2.add_door(door1)
        room2.add_door(door2)
        self.rooms.append(room1)
        self.rooms.append(room2)
        self.doors.append(door1)
        self.doors.append(door2)

        # Create NPCs
        npc1 = NPC("A suspiciously happy looking orc")
        npc2 = NPC("The kerstman")
        npc3 = NPC("A dancing strawberry")
        room1.add_npc(npc1)
        room1.add_npc(npc2)
        room1.add_npc(npc3)
        self.npcs.append(npc1)
        self.npcs.append(npc2)
        self.npcs.append(npc3)

        # Create items
        item1 = Item("A health potion")
        item2 = Item("A sword")
        room1.add_item(item1)
        room1.add_item(item2)
        self.items.append(item1)
        self.items.append(item2)

        self.player.current_room = room1

    def play(self):
        while True:
            print("What do you want to do?")
            print("(0) Look around")
            print("(1) Look for a way out")
            print("(2) Look for company")
            print("(3) Look for items")
            print("(4) QuickSave")
            print("(5) QuickLoad")
            choice = input("> ")
            if choice == "0":
                self.look_around()
            elif choice == "1":
                self.look_for_way_out()
            elif choice == "2":
                self.look_for_company()
            elif choice == "3":
                self.look_for_items()
            elif choice == "4":
                self.quicksave()
            elif choice == "5":
                self.quickload()
            else:
                print("Invalid choice")

    def look_around(self):
        print(self.player.current_room.description)

    def look_for_way_out(self):
        print("You look around for doors.")
        for i, door in enumerate(self.player.current_room.doors):
            print(f"({i}) {door.description}")
        choice = input("Which door do you want to go through? ")
        if int(choice) < len(self.player.current_room.doors):
            self.player.current_room.doors[int(choice)].interact(self.player)
        else:
            print("Invalid choice")

    def look_for_company(self):
        print("You look around for NPCs.")
        for i, npc in enumerate(self.player.current_room.npcs):
            print(f"({i}) {npc.description}")
        choice = input("Which NPC do you want to interact with? ")
        if int(choice) < len(self.player.current_room.npcs):
            self.player.current_room.npcs[int(choice)].interact(self.player)
        else:
            print("Invalid choice")

    def look_for_items(self):
        print("You look around for items.")
        for i, item in enumerate(self.player.current_room.items):
            print(f"({i}) {item.description}")
        choice = input("Which item do you want to pick up? ")
        if int(choice) < len(self.player.current_room.items):
            self.player.current_room.items[int(choice)].interact(self.player)
        else:
            print("Invalid choice")

    def quicksave(self):
        data = {
            "player": {
                "name": self.player.name,
                "health": self.player.health,
                "damage": self.player.damage,
                "current_room": self.rooms.index(self.player.current_room)
            },
            "rooms": [
                {
                    "description": room.description,
                    "doors": [self.doors.index(door) for door in room.doors],
                    "npcs": [self.npcs.index(npc) for npc in room.npcs],
                    "items": [self.items.index(item) for item in room.items]
                } for room in self.rooms
            ],
            "doors": [
                {
                    "description": door.description,
                    "room_behind": self.rooms.index(door.room_behind)
                } for door in self.doors
            ],
            "npcs": [
                {
                    "description": npc.description,
                    "health": npc.health,
                    "damage": npc.damage
                } for npc in self.npcs
            ],
            "items": [
                {
                    "description": item.description,
                    "health_bonus": item.health_bonus
                } for item in self.items
            ]
        }
        with open("quicksave.json", "w") as f:
            json.dump(data, f)
        print("Game saved!")

    def quickload(self):
        try:
            with open("quicksave.json", "r") as f:
                data = json.load(f)
            self.player.name = data["player"]["name"]
            self.player.health = data["player"]["health"]
            self.player.damage = data["player"]["damage"]
            self.player.current_room = self.rooms[data["player"]["current_room"]]
            for i, room in enumerate(self.rooms):
                room.description = data["rooms"][i]["description"]
                room.doors = [self.doors[j] for j in data["rooms"][i]["doors"]]
                room.npcs = [self.npcs[j] for j in data["rooms"][i]["npcs"]]
                room.items = [self.items[j] for j in data["rooms"][i]["items"]]
            for i, door in enumerate(self.doors):
                door.description = data["doors"][i]["description"]
                door.room_behind = self.rooms[data["doors"][i]["room_behind"]]
            for i, npc in enumerate(self.npcs):
                npc.description = data["npcs"][i]["description"]
                npc.health = data["npcs"][i]["health"]
                npc.damage = data["npcs"][i]["damage"]
            for i, item in enumerate(self.items):
                item.description = data["items"][i]["description"]
                item.health_bonus = data["items"][i]["health_bonus"]
            print("Game loaded!")
        except FileNotFoundError:
            print("No quicksave found")

game = Game()
game.play()
